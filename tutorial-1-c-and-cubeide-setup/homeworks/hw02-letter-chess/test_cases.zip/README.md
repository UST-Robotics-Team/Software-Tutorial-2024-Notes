test case 1 tests O K X
test case 2 tests O T H K
test case 3 tests O X U K
